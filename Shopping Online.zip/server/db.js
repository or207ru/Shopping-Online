const mysql = require('mysql');

// connection configuration
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'mystore',
    dateStrings: ['DATE', 'DATETIME']
})

// create connection
connection.connect(err => {
    if (err) {
        console.error('error connecting: ' + err.stack);
        return;
    }
    console.log('connected as id ' + connection.threadId);
})

// making the query to work with promis
const myQuery = (qry) => {
    return new Promise((resolve, reject) => {
        connection.query(qry, (err, results) => {
            err ? reject(err) : resolve(results)
        })
    })
}

module.exports = { myQuery }
