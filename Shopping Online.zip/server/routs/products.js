// importing
const router = require("express").Router()
const { myQuery } = require('../db')
const bcrypt = require('bcrypt')
const jwt = require("jsonwebtoken")
const { vtUser, permission } = require("../middleware")


// get all categories
router.get('/cat', vtUser, async (req, res) => {
    const qry = `SELECT * FROM Categories`
    try {
        return res.json(await myQuery(qry))
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// get all products
router.get('/all_products', vtUser, async (req, res) => {
    const qry = `SELECT product_name FROM Products`
    try {
        return res.json(await myQuery(qry))
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// get products of certien category
router.get('/prods/:cat', vtUser, async (req, res) => {
    const qry = `SELECT * FROM Products WHERE
    category_name="${req.params.cat}";`
    try {
        return res.json(await myQuery(qry))
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// get specific product
router.get('/prod/:name', vtUser, async (req, res) => {
    try {
        const get = await myQuery(`SELECT * FROM Products WHERE product_name = "${req.params.name}"`)
        return res.json(get)
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// get random product
router.get('/rand_prod', vtUser, async (req, res) => {
    try {
        return res.json(await myQuery(`SELECT * FROM Products ORDER BY rand() LIMIT 1`))
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// get products count
router.get('/products_count', async (req, res) => {
    try {
        const msg = (await myQuery(`SELECT COUNT(*) FROM Products`))[0]
        return res.json(Object.values(msg)[0])
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// adding new product
router.post('/add_prod', vtUser, permission("admin"), async (req, res) => {
    const { product_name, category_name, price, img } = req.body
    if (!product_name || !category_name || !price || !img)
        return res.status(400).json({ err: true, msg: 'missing some info' })
    const qry = `INSERT INTO Products (product_name, category_name, price, img)
    values ('${product_name}', '${category_name}', ${price}, '${img}');`
    try {
        await myQuery(qry)
        return res.status(201).json({ err: false, msg: "product added successfuly" })
    } catch (err) {
        return res.status(500).json({ err: true, msg: err })
    }
})

// updating product
router.put('/update', vtUser, permission("admin"), async (req, res) => {
    const { product_name, category_name, price, img } = req.body
    if (!product_name || !category_name || !price || !img)
        return res.status(400).json({ err: true, msg: 'missing some info' })
    const qry = `UPDATE Products SET product_name = '${product_name}',
    category_name = '${category_name}', price = ${price}, img = '${img}' WHERE product_name = '${product_name}';`
    try {
        await myQuery(qry)
        return res.json({ err: false, msg: "update successfuly" })
    } catch (err) {
        return res.status(500).json({ err: true, msg: err })
    }
})


module.exports = router