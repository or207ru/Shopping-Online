// importing
const router = require("express").Router()
const { myQuery } = require('../db')
const bcrypt = require('bcrypt')
const jwt = require("jsonwebtoken")
const { vtUser, existUser, permission } = require("../middleware")


// get all users ** inner use
router.get('/users', vtUser, async (req, res) => {
    try {
        return res.json(await myQuery(`SELECT * FROM Users`))
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// check if user exist
router.get('/user/:id', existUser, (req, res) => {
    // return true if this id is free to use and false otherwhise
    return res.json(!req.count)
})

// pulling specific value from user details
router.get('/auto_complete/:value', vtUser, permission("user"), async (req, res) => {
    const user_id = req.user.user_id
    const value = req.params.value
    const qry = `SELECT ${value} FROM Users WHERE user_id=${user_id};`
    try {
        return res.json((await myQuery(qry))[0][value])
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// handling new registration. restricting duplicate id for users
router.post('/register', existUser, async (req, res) => {
    try {
        // reciving info from the body
        const { user_id, first_name, last_name, email, password, city, street, admin_pass } = req.body
        if (!user_id || !first_name || !last_name || !email || !password || !city || !street)
            return res.status(400).json({ err: true, msg: 'missing some info' })

        // check if the user allready sign
        if (req.count)
            return res.status(409).json({ err: true, msg: 'this id is allready sign - just loggin' })

        // create hash password
        const hash = await bcrypt.hash(password, 10)

        // create the query and add some extras for admin case
        const is_admin = admin_pass == process.env.ADMIN_PASS
        let qry = `INSERT INTO Users (user_id, first_name, last_name, email, password, city, street ${is_admin ? ", role" : ""})
        VALUES ("${user_id}", "${first_name}", "${last_name}", "${email}", "${hash}", "${city}", "${street}" ${is_admin ? ", 'admin'" : ""})`

        // execute the query
        await myQuery(qry)
        return res.status(201).json({ err: false, msg: "user added successfuly" })

    } catch (err) {
        return res.status(500).json({ err: true, msg: err })
    }
})

// handeling login and provide token if login succeed
router.post('/login', async (req, res) => {
    try {
        // recive info from the body
        const { user_id, password } = req.body
        if (!user_id || !password)
            return res.status(400).json({ err: true, msg: 'missing some info' })
        // cheking authentication
        const qry = `SELECT * FROM Users WHERE user_id = "${user_id}"`
        const user = await myQuery(qry)
        if (user.length) {
            const didPass = await bcrypt.compare(password, user[0].password)

            if (didPass) {
                const token = jwt.sign(
                    // create token for 10 houers validity
                    { ...user[0], exp: Math.floor(Date.now() / 1000) + (10 * 60 * 60) }, process.env.TOKEN_SECRET)
                return res.json({ err: false, token })
            }
        } // kicking out the rude user who gave us wrong info
        return res.status(401).json({ err: true, msg: "some bad info" })

    } catch (err) {
        return res.status(500).json(({ err: true, msg: err }))
    }
})

module.exports = router