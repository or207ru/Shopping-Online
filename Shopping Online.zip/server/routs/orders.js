// importing
const router = require("express").Router()
const { myQuery } = require('../db')
const bcrypt = require('bcrypt')
const jwt = require("jsonwebtoken")
const { vtUser, permission, preventDuplication } = require("../middleware")


// get the last cart of user
router.get('/cart/:user_id', vtUser, permission("user"), async (req, res) => {
    try {
        const qry = `SELECT * FROM Carts WHERE user_id = ${req.params.user_id}
        order by cart_id desc limit 1;`
        return res.json((await myQuery(qry))[0])
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// get count of orders done in this date
router.get('/date/:date', vtUser, permission("user"), async (req, res) => {
    try {
        const qry = `SELECT count(*) FROM orders WHERE shiping_date = ${req.params.date};`
        return res.json((await myQuery(qry))[0]['count(*)'])
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// create new cart for user
router.post('/new_cart', vtUser, permission("user"), async (req, res) => {
    const { user_id } = req.body
    if (!user_id) return res.status(400).json({ err: true, msg: 'missing some info' })
    try {
        await myQuery(`INSERT INTO Carts (user_id) VALUES (${user_id});`)
        return res.json({ err: false, msg: "new cart opend" })
    } catch (err) {
        return res.status(500).json({ err: true, msg: err })
    }

})

// get items of cart
router.get('/items/:cart_id', vtUser, permission("user"), async (req, res) => {
    try {
        return res.json(await myQuery(`SELECT * FROM Items WHERE cart_id = ${req.params.cart_id}`))
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// add item to cart
router.post('/add_item_to_cart', vtUser, permission("user"), preventDuplication, async (req, res) => {
    const { product_name, cart_id, amount, total_price } = req.body
    if (!cart_id || !product_name || !amount || !total_price || amount <= 0)
        return res.status(400).json({ err: true, msg: 'missing some info or not positive amount' })
    try {
        await myQuery(req.qry)
        return res.json({ err: false, msg: "item added successfuly" })
    } catch (err) {
        return res.status(500).json({ err: true, msg: err })
    }
})

// del item from cart
router.delete('/del_item_from_cart/:cart_id/:product_name', vtUser, permission("user"), async (req, res) => {
    const product_name = req.params.product_name
    const cart_id = req.params.cart_id
    if (!cart_id || !product_name)
        return res.status(400).json({ err: true, msg: 'missing some info' })
    try {
        const qry = `DELETE FROM Items WHERE product_name="${product_name}" AND cart_id=${cart_id};`
        await myQuery(qry)
        return res.json({ err: false, msg: "item deleted successfuly" })
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// del all items from cart
router.delete('/del_all_items/:cart_id', vtUser, permission("user"), async (req, res) => {
    const cart_id = req.params.cart_id
    if (!cart_id)
        return res.status(400).json({ err: true, msg: 'missing some info' })
    try {
        const qry = `DELETE FROM Items WHERE cart_id=${cart_id};`
        await myQuery(qry)
        return res.json({ err: false, msg: "item deleted successfuly" })
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// get orders count
router.get('/orders_count', async (req, res) => {
    try {
        const msg = (await myQuery(`SELECT COUNT(*) FROM Orders`))[0]
        return res.json(Object.values(msg)[0])
    } catch (error) {
        return res.status(500).json({ err: true, msg: error })
    }
})

// handeling submiting order by adding to order list and mark cart as completed
router.post('/submit_order', vtUser, permission("user"), async (req, res) => {

    const { user_id, cart_id, final_price, city, street,
        shiping_date, four_digit_of_cc } = req.body
    if (!user_id || !cart_id || !final_price || !city || !street
        || !shiping_date || !four_digit_of_cc)
        return res.status(400).json({ err: true, msg: 'missing some info' })

    try {
        const order_qry = `INSERT INTO Orders (user_id, cart_id, final_price, city,
            street, shiping_date, four_digit_of_cc) VALUES
            (${user_id}, ${cart_id}, ${final_price}, "${city}", "${street}",
             '${shiping_date}', ${four_digit_of_cc});`
        await myQuery(order_qry)
        const cart_qry = `UPDATE Carts SET completed = true WHERE cart_id = ${cart_id}`
        await myQuery(cart_qry)
        return res.json({ err: false, msg: "order done successfuly" })
    } catch (err) {
        return res.status(500).json({ err: true, msg: err })
    }
})


module.exports = router