const jwt = require('jsonwebtoken')
const { myQuery } = require('./db')

// verify token authentication and decrypting the token into the body
const vtUser = (req, res, next) => {
    jwt.verify(req.headers.token, process.env.TOKEN_SECRET, (err, payload) => {
        if (err) return res.status(403).json({ err: true, msg: err.message })
        req.user = payload
        next()
    })
}

// check quantities or user existens
const existUser = async (req, res, next) => {
    id = req.params.id ? req.params.id : req.body.user_id
    try {
        const qry = `SELECT COUNT(*) FROM users WHERE user_id=${id}`
        const msg = (await myQuery(qry))[0]
        const count = Object.values(msg)[0]
        req.count = count
        next()
    } catch (error) {
        return res.status(500).json({ err: true, msg: err })
    }
}

// check if item allready in the cart and react accordingly
const preventDuplication = async (req, res, next) => {
    const { product_name, cart_id, amount, total_price } = req.body
    try {
        const item = (await myQuery(`SELECT * FROM Items WHERE cart_id=${cart_id}
         AND product_name="${product_name}";`))[0]
        req.qry = item ? `UPDATE Items SET amount = ${item.amount + +amount},
        total_price = ${item.total_price + total_price} WHERE item_id=${item.item_id};` :
            `INSERT INTO Items (product_name, cart_id, amount, total_price) VALUES
            ("${product_name}", ${cart_id}, ${amount}, ${total_price});`
        next()
    } catch (err) {
        return res.status(500).json({ err: true, msg: err })
    }
}

// managing allowed actions for users and admin
const permission = (role) => {
    return async (req, res, next) => {
        if (role !== req.user.role)
            return res.status(403).json({ err: true, msg: "you are not allowed for this action" })
        next()
    }
}

module.exports = { vtUser, permission, existUser, preventDuplication }