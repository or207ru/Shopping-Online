// importing
const express = require("express")
const path = require('path')
const multer = require("multer")
const dotenv = require("dotenv")
dotenv.config()
require("./db")
const port = 1000

// 
const fileStorageEngine = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, './public/uploads')
    },
    filename: (req, file, cb) => {
        cb(null, file.originalname)
    }
})

// setters
const app = express()
app.use(require('cors')())
app.use(express.json())
app.use(express.static(path.join(__dirname, 'public')))
const upload = multer({ storage: fileStorageEngine })

// routing
app.use('/api/users', require("./routs/users"))
app.use('/api/products', require("./routs/products"))
app.use('/api/orders', require("./routs/orders"))

// saving img into static folder
app.post("/single", upload.single("image"), (req, res) => {
    res.send(req.file.originalname)
})

// sending img which saved in the server
app.get("/img/:name", (req, res) => {
    let dest = path.join(__dirname, "/public/uploads/" + req.params.name)
    res.sendFile(dest)
})

// raising server
app.listen(port, () => {
    console.log(`hii from port ${port}`)
})

