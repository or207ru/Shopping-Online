import { Component, OnInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'TENE shop 🥦';

  ngOnInit(): void {
    localStorage.clear()
  }

  ngOnDestroy(): void {
    localStorage.clear()
  }
}
