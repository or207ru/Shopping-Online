import { Component, OnInit, Input } from '@angular/core';
import { NotificationService } from 'src/app/services/notification.service';

@Component({
  selector: 'app-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.css']
})
export class NotificationComponent implements OnInit {

  constructor(public _notify: NotificationService) { }


  @Input() user
  @Input() order
  public orders: number
  public products: number
  public msg: string

  // set the orders and products of the store
  ngOnInit(): void {
    // return the number of orders done in the store
    this._notify.ordersCount().subscribe(
      (res: any) => this.orders = res,
      (err: String) => console.log(err)
    )

    // return the number of products done in the store
    this._notify.productsCount().subscribe(
      (res: number) => this.products = res,
      (err: String) => console.log(err)
    )
  }


}
