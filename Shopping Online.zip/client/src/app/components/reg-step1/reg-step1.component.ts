import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reg-step1',
  templateUrl: './reg-step1.component.html',
  styleUrls: ['./reg-step1.component.css']
})
export class RegStep1Component implements OnInit {

  constructor(
    public _user: UsersService,
    public _fb: FormBuilder,
    private _router: Router) { }

  // reg values
  public myForm: FormGroup
  // manage admin registration
  public admin: boolean = false
  // posses the error msg of reg
  public error_msg_id: string = ""

  // submiting the first field of reg, check if user id is free and handle admin case
  public handleSubmit() {
    console.log
    this._user.reg1 = this.myForm.value
    this._user.isFree(this.myForm.value.user_id).subscribe(
      (res: boolean) => {
        if (this.admin && this.myForm.value.admin_pass && res)
          this._user.admin_pass = this.myForm.value.admin_pass
        if
          (res) this._router.navigateByUrl('/lobby/reg2')
        else
          this.error_msg_id = "this id is taken"
      }, (err) => console.log(err)
    )
  }

  // changing admin reg option
  public flip() {
    this.admin = !this.admin
  }

  // initialize the form for reg
  ngOnInit(): void {
    this.myForm = this._fb.group({
      admin_pass: "",
      user_id: ["", Validators.required],
      email: ["", Validators.required],
      password: ["", Validators.required],
      confirm_password: ["", Validators.required],
    })
  }

}
