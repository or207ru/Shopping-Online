import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AdminService } from 'src/app/services/admin.service';
import { ProductsService } from 'src/app/services/products.service';
import { ShopComponent } from '../shop/shop.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  constructor(
    public _fb: FormBuilder,
    public _prod: ProductsService,
    public _admin: AdminService,
    public _shop: ShopComponent,
    public _router: Router,
  ) { }

  public myForm: FormGroup;
  public all_categories;
  public file_data;

  // gets the categories of the shop
  public getCategories() {
    this._prod.getAllCategories().subscribe(
      res => this.all_categories = (res as any[]).map(cat => cat.category_name),
      err => console.log(err)
    )
  }

  // choose file to upload
  public file(e) {
    this.file_data = e.target.files[0]
  }

  // upload the file
  public saveImg(e) {
    const data = new FormData()
    data.append('image', this.file_data)
    this._prod.img(data).subscribe(
      (res: any) => {
        console.log(res)
      },
      (err: any) => {
        this.myForm.controls.img.setValue(err.error.text)
      }
    )
  }

  // add new product
  add() {
    this._admin.addNewProduct(this.myForm.value).subscribe(
      res => {
        this.myForm.reset()
        this.myForm.markAsPristine()
        this.myForm.markAsUntouched()
        this.myForm.controls.product_name.setErrors(null)
        this.myForm.controls.price.setErrors(null)
        this.myForm.controls.img.setErrors(null)
        this.myForm.controls.category_name.setErrors(null)
        this.reload('/hall/manage')
      }
    )
  }

  public async reload(url: string): Promise<boolean> {
    await this._router.navigateByUrl('/hall/cart', { skipLocationChange: true });
    return this._router.navigateByUrl(url);
  }

  ngOnInit(): void {
    this.getCategories()
    this.myForm = this._fb.group({
      product_name: ["", Validators.required],
      price: ["", Validators.required],
      img: ["", Validators.required],
      category_name: ["", Validators.required],
    })
  }

}
