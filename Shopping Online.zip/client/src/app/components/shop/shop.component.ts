import { Component, OnInit } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-shop',
  templateUrl: './shop.component.html',
  styleUrls: ['./shop.component.css']
})
export class ShopComponent implements OnInit {

  constructor(public _prod: ProductsService,
    public _fb: FormBuilder,
    public _user: UsersService) { }

  public allCats;
  public prods;
  public categoryVal = 0
  public myForm: FormGroup
  randProd: string


  // gets the products in this category
  public getProd() {
    this._prod.getAllProducts(this.allCats[this.categoryVal]).subscribe(
      res => this.prods = res,
      err => console.log(err)
    )
  }

  // get random product from the shop
  public getRand() {
    this._prod.getRandomProduct().subscribe(
      (res: any) => this.randProd = res[0].product_name,
      err => console.log(err)
    )
  }

  // gets the categories of the shop
  public getCategories() {
    this._prod.getAllCategories().subscribe(
      res => {
        this.allCats = (res as any[]).map(item => item.category_name)
        this.getProd()
      },
      err => console.log(err)
    )
  }

  // handeling search view
  public handleSearch() {
    this._prod.getProduct(this.myForm.value.product_name).subscribe(
      (res: any) => {
        this.allCats = ["SEARCHED PRODUCT"]
        this.prods = res
        this._prod.onSearch = true
      },
      err => console.log(err)
    )
  }

  // handeling close search
  public handleCloseSearch() {
    this._prod.onSearch = false
    this.myForm.reset()
    this.getCategories()
  }

  ngOnInit(): void {
    this.getRand()
    this.myForm = this._fb.group
      ({ product_name: ['', Validators.required] })
    this.getCategories()
  }

}




