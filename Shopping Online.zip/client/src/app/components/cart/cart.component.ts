import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { OrdersService } from 'src/app/services/orders.service';
import { UsersService } from 'src/app/services/users.service';
import { ProductsService } from 'src/app/services/products.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(
    public _user: UsersService,
    public _order: OrdersService,
    public _router: Router,
    public _prod: ProductsService,
    public _active_route: ActivatedRoute) { }

  // determinant in wich contex the component react by the path
  public path: string;

  // minimize cart
  public hide: boolean = false;

  // product tosearch in the receipt
  searcher = '';

  // deleting specific product from cart
  public handleDel(product_name) {
    this._order.delItem(product_name)
    this._order.getAllItems()
  }

  // deleting all products from cart
  public handleTotalDel() {
    this._order.delAllItems()
    this._order.getAllItems()
  }

  // moving to order stage
  public goToOrder() {
    this._router.navigateByUrl("/order")
  }

  // back to cart
  public backToCart() {
    this._router.navigateByUrl("/hall")
  }

  ngOnInit(): void {
    this._order.getAllItems()
    this.path = this._active_route.snapshot.url[0].path
  }

}
