import { Component, OnInit } from '@angular/core';
import { UsersService } from 'src/app/services/users.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reg-step2',
  templateUrl: './reg-step2.component.html',
  styleUrls: ['./reg-step2.component.css']
})
export class RegStep2Component implements OnInit {

  constructor(
    public _user: UsersService,
    public _fb: FormBuilder,
    private _router: Router) { }

  // reg values
  public myForm: FormGroup

  // submiting the second part of registration
  public handleSubmit() {
    this._user.register({
      ...this._user.reg1,
      ...this.myForm.value,
      admin_pass: this._user.admin_pass
    }).subscribe(
      (res: any) => {
        this._router.navigateByUrl('/lobby/login')
      }, err => {
        console.log(err)
      }
    )
  }

  // initialize the form for reg
  ngOnInit(): void {
    this.myForm = this._fb.group({
      first_name: ["", Validators.required],
      last_name: ["", Validators.required],
      city: ["", Validators.required],
      street: ["", Validators.required],
    })
  }

}
