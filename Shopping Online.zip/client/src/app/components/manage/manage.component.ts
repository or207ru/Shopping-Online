import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { AdminService } from 'src/app/services/admin.service';
import { ProductsService } from 'src/app/services/products.service';


@Component({
  selector: 'app-manage',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.css']
})
export class ManageComponent implements OnInit {

  constructor(
    public _fb: FormBuilder,
    public _prod: ProductsService,
    public _admin: AdminService) { }

  public all_products;
  public product_field;

  // gets the products of the shop
  public getAllProds() {
    this._admin.getAllProducts().subscribe(
      res => this.all_products = (res as any[]).map(prod => prod.product_name),
      err => console.log(err)
    )
  }

  ngOnInit(): void {
    this.product_field = {};
    this.getAllProds()
  }

}

