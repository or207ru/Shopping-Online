import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from 'src/app/services/users.service';
import { Router } from '@angular/router';
import { OrdersService } from 'src/app/services/orders.service';

@Component({
  selector: 'app-shiping',
  templateUrl: './shiping.component.html',
  styleUrls: ['./shiping.component.css']
})
export class ShipingComponent implements OnInit {

  constructor(
    public _fb: FormBuilder,
    public _user: UsersService,
    private _order: OrdersService,
    private _router: Router,
  ) { }

  public myForm: FormGroup
  public error_msg = ""
  public cc_err = false

  public handleOrder() {
    this._order.getDateCount(this.myForm.value.shiping_date).subscribe(
      res => {
        if (res < 3) {
          this.create_receipt()
          this._order.delAllItems()
          this._order.getAllItems()
          this._order.setCart(this._user.user.user_id)
          this._router.navigateByUrl("/hall")
        } else {
          this.error_msg = "choose another date this one is ocupide"
        }
      }
    )

  }

  public async completeVal(val) {
    this._user.autoComplete(val).subscribe(
      (res: any) => this.myForm.controls[val].setValue(res))
  }

  // sending the order request
  public create_receipt() {
    let receipt = {
      user_id: this._user.user.user_id,
      cart_id: this._order.cart.cart_id,
      final_price: this._order.totalAmount(),
      ...this.myForm.value
    }
    // sending the order and sugesting to download the receipt
    this._order.addOrder(receipt).subscribe(
      () => {
        let receipt_name = window.prompt(`👍 succssesfuly Done. \nPress OK for downloading the receipt \nOtherwise press CANCEL`,
          (new Date).toJSON().slice(0, 10) + "_" + this._user.user.first_name + '.pdf')
        if (receipt_name !== null) {
          this._order.createPdf(receipt_name, this.build_receipt())
        }
      },
      err => console.log(err)
    )
  }

  // creatin the receipt content
  public build_receipt() {
    let receipt = `
    done at: ${(new Date).toJSON().slice(0, 10)}
    order for: ${(this._user.user.first_name)} ${(this._user.user.last_name)}
    shiping date: ${this.myForm.value.shiping_date}
    address: ${this.myForm.value.city}, ${this.myForm.value.street}\n
      cart items:\n`
    let total_price = 0
    for (let item of this._order.items) {
      total_price += item.total_price
      receipt += `\t${item.product_name} * ${item.amount}  =  ${item.total_price}\n`
    }
    receipt += `\t--------\n\ttotal price:  ${total_price}
      \n Thanks for buying at TENE_STORE :)\n\n\n\nprinted at ${(new Date()).toJSON().slice(0, 10)}`
    return receipt
  }

  ngOnInit(): void {
    this.myForm = this._fb.group({
      city: ["", Validators.required],
      street: ["", Validators.required],
      shiping_date: ["", Validators.required],
      four_digit_of_cc: ["", [Validators.required, Validators.maxLength(4), Validators.minLength(4)]],
    })
  }


}