import { Component, Input } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UsersService } from 'src/app/services/users.service';
import { QuantityComponent } from '../quantity/quantity.component';
import { Router } from '@angular/router';
import { ProductsService } from 'src/app/services/products.service';
import { AdminService } from 'src/app/services/admin.service';
import { ManageComponent } from '../manage/manage.component';
import { EditComponent } from '../edit/edit.component';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})

export class ProductComponent {

  public amount: number = 1;
  public inCart: boolean = false;
  @Input() product;
  public role: string


  constructor(
    public _dialog: MatDialog,
    public _user: UsersService,
    public _router: Router,
    public _prod: ProductsService,
    public _admin: AdminService,
    public _manage: ManageComponent,
    public _edit: EditComponent) { }

  public edit(prod) {
    this._prod.product.setValue(prod.product_name)
    this._prod.selected_action = 1
  }

  public openDialog(): void {
    const dialogRef = this._dialog.open(QuantityComponent, {
      width: '150px',
      data: { amount: this.amount, name: this.product.product_name, price: this.product.price }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result != undefined) {
        this.amount = result > 1 ? result : 1;
        this.inCart = result > 0
      }
    });
  }
}



