import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor() { }

  public imgs = [`https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUrByQkgHQwkNkhIQir9bTPDkdam6iJT-_Yw&usqp=CAU`,
    `https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT16EceML_F3jcjFR698oKy6xVjD4WKKttrYg&usqp=CAU`,
    'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzQWImyRO0HLhXvdFTMmwEuzWz5Dk4qH-bFg&usqp=CAU',
    'https://image.made-in-china.com/202f0j00obZRUgAYbNkf/3-Layer-Fruit-Shop-Produce-Display-Rack.jpg',
    'https://media.istockphoto.com/photos/assorted-fruits-in-modern-fruit-market-picture-id186792072?k=6&m=186792072&s=170667a&w=0&h=FANgJAvZnC7ej5cKkxg4Ta-3JPsobF70ivc3E3R2DXw='
  ]

  public img = this.selectImage()

  public selectImage() {
    return Math.floor(Math.random() * this.imgs.length)
  }

  ngOnInit(): void {
    let interval_id = setInterval(() => {
      if (window.location.pathname.split('/').indexOf('lobby') == -1) {
        clearInterval(interval_id)
      }
      let new_img = this.selectImage()
      while (new_img == this.img) { new_img = this.selectImage() }
      this.img = new_img
    }, 6600)
  }


}
