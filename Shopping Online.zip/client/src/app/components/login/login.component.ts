import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    public _user: UsersService,
    public _fb: FormBuilder,
  ) { }

  // login values
  public myForm: FormGroup

  // posses the error msg of reg
  public error_msg_id: string = ""

  // submiting the login values
  public handleSubmit() {
    this._user.login(this.myForm.value).subscribe(
      (res: any) => {
        localStorage.token = res.token
        this._user.startNewSession()
        this.myForm.reset()
        this.myForm.markAsPristine()
        this.myForm.markAsUntouched()
        this.myForm.controls.user_id.setErrors(null)
        this.myForm.controls.password.setErrors(null)
      }, err => this.error_msg_id = "wrong password or user id"
    )
  }

  // initialize the form for login
  ngOnInit(): void {
    this.myForm = this._fb.group({
      user_id: ["", Validators.required],
      password: ["", Validators.required],
    })
  }

}
