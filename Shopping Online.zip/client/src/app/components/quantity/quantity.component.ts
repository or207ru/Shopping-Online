import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { OrdersService } from 'src/app/services/orders.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-quantity',
  templateUrl: './quantity.component.html',
  styleUrls: ['./quantity.component.css']
})

export class QuantityComponent {

  constructor(
    public dialogRef: MatDialogRef<QuantityComponent>,
    private _order: OrdersService,
    public _router: Router,
    @Inject(MAT_DIALOG_DATA) public data: { amount: number, name: string, price: number }) { }


  public async reload(url: string): Promise<boolean> {
    await this._router.navigateByUrl('/hall/manage', { skipLocationChange: true });
    return this._router.navigateByUrl(url);
  }

  public buy(amount) {
    if (amount > 0) {
      this._order.addItem(this.data.name, amount, amount * this.data.price)
      this._order.getAllItems()
      this.reload('/hall/cart')
    }
  }
}
