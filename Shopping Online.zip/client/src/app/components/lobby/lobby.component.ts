import { Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { OrdersService } from 'src/app/services/orders.service';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-lobby',
  templateUrl: './lobby.component.html',
  styleUrls: ['./lobby.component.css']
})
export class LobbyComponent {

  constructor(
    public _user: UsersService,
    public _router: Router,
    public _order: OrdersService,) { }

  public handleEntering() {
    this._router.navigateByUrl('/hall/' + this._user.nav())
  }

  @ViewChild('buy', { static: false })
  set input(element: ElementRef<HTMLInputElement>) {
    if (element) {
      element.nativeElement.focus()
    }
  }

}
