import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { jsPDF } from 'jspdf'

@Injectable({
  providedIn: 'root'
})
export class OrdersService {

  constructor(private _http: HttpClient) { }

  private order_url = `http://localhost:1000/api/orders/`

  public cart;
  public items;

  // seting the current cart
  public setCart(user_id) {
    this.getLastCart(user_id).subscribe(
      res => {
        if (res == undefined || (res as any).completed) {
          this.newCart(user_id)
          this.items = []
        } else {
          this.cart = res
          this.getItems((res as any).cart_id).subscribe(
            res => {
              this.items = res
            },
            err => console.log(err)
          )
        }
      }, err => console.log(err)
    )
  }



  // build new cart
  public newCart(user_id) {
    this.createNewCart(user_id).subscribe(
      res => this.setCart(user_id),
      err => console.log(err)
    )
    this.getAllItems()
  }

  // check if there is open cart
  public hasOpenCart() {
    return this.hasEverCart() && !this.cart.completed
  }

  // check if it was ever cart to the user
  public hasEverCart() {
    return !!this.cart
  }

  // get the items in the cart
  public getAllItems() {
    if (!!this.cart && Object.keys(this.cart).length) {
      this.getItems(this.cart.cart_id).subscribe(
        res => {
          this.items = res
        },
        err => console.log(err)
      )
    }
  }

  // calculate the total amount of the cart
  public totalAmount() {
    if (!!this.items) {
      let sum = 0
      for (let item of this.items) {
        sum += item.total_price
      }
      return Math.round(10 * sum) / 10
    }
  }

  // deleting item from the cart
  public delItem(product_name) {
    this.delItemFromCart(this.cart.cart_id, product_name).subscribe()
  }

  // deleting all items from the cart
  public delAllItems() {
    this.delAllItemsFromCart(this.cart.cart_id).subscribe()
  }

  // adding item to the cart
  public addItem(product_name, amount, total_price) {
    this.addItemToCart({
      "product_name": product_name,
      "cart_id": this.cart.cart_id,
      "amount": amount,
      "total_price": total_price
    }).subscribe()
  }

  // create receipt in pdf format
  public createPdf(receipt_name, content) {
    const receipt = new jsPDF()
    receipt.text(content, 40, 40)
    receipt.save(receipt_name)
  }


  // request //

  // gets the last cart of this user
  public getLastCart(user_id) {
    return this._http.get(this.order_url + "cart/" + user_id,
      { headers: { 'token': localStorage.token } }
    )
  }

  // create new cart for user
  public createNewCart(user_id) {
    return this._http.post(this.order_url + "new_cart", { user_id },
      {
        headers: {
          'token': localStorage.token,
          'Content-Type': 'application/json'
        }
      }
    )
  }

  // get items of cart
  public getItems(cart_id) {
    return this._http.get(this.order_url + "items/" + cart_id,
      { headers: { 'token': localStorage.token } }
    )
  }
  // add item to cart
  public addItemToCart(new_item) {
    return this._http.post(this.order_url + "add_item_to_cart", new_item,
      {
        headers: {
          'token': localStorage.token,
          'Content-Type': 'application/json'
        }
      }
    )
  }

  // return false if there is more than 3 orders to this date
  public getDateCount(date) {
    return this._http.get(this.order_url + '/date/' + date,
      { headers: { 'token': localStorage.token } })
  }

  // del item from cart
  public delItemFromCart(cart_id, product_name) {
    return this._http.delete(this.order_url +
      "del_item_from_cart/" + cart_id + "/" + product_name,
      { headers: { 'token': localStorage.token } })
  }

  // del all items from cart
  public delAllItemsFromCart(cart_id) {
    return this._http.delete(this.order_url +
      "del_all_items/" + cart_id,
      { headers: { 'token': localStorage.token } })
  }

  // adding order and mark the cart as completed
  public addOrder(body) {
    return this._http.post(this.order_url + "submit_order", body,
      {
        headers: {
          'token': localStorage.token,
          'Content-Type': 'application/json'
        }
      }
    )
  }

}


