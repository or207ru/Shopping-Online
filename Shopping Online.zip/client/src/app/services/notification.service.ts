import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  constructor(private _http: HttpClient) { }

  private url_prolog = "http://localhost:1000/api/"

  // return the number of products in the shop
  public productsCount() {
    return this._http.get(this.url_prolog + "products/products_count")
  }

  // return the number of orders done in the shop
  public ordersCount() {
    return this._http.get(this.url_prolog + "orders/orders_count")
  }







}


