import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import jwtdecode from 'jwt-decode'
import { OrdersService } from './orders.service';

@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(
    private _http: HttpClient,
    private _router: Router,
    private _order: OrdersService) { }

  private user_url = `http://localhost:1000/api/users/`

  // supply the name of the user
  public user: any = { first_name: "guest", last_name: "" }

  // possess the id, email, password
  public reg1: any = {}

  // password for admin registration
  public admin_pass: string = ""

  // seting the route according the role
  public nav(): string {
    return this.user.role === "admin" ? "manage" : "cart"
  }

  // send the registration request to the server
  public register(body) {
    this.reg1 = {}
    this.admin_pass = ""
    return this._http.post(`${this.user_url}register`, body, {
      headers: { 'Content-Type': 'application/json' }
    })
  }

  // send the login request to the server
  public login(body) {
    return this._http.post(`${this.user_url}login`, body, {
      headers: { 'Content-Type': 'application/json' }
    })
  }

  // complete data from user saved info
  public autoComplete(field) {
    return this._http.get(`${this.user_url}auto_complete/${field}`,
      { headers: { 'token': localStorage.token } })
  }

  // check if id is allready in the db
  public isFree(user_id) {
    return this._http.get(`${this.user_url}user/${user_id}`)
  }

  // decoded the token
  public startNewSession() {
    this.user = jwtdecode(localStorage.token)
    if (this.user.role == "user")
      this._order.setCart(this.user.user_id)
  }

  // check if token is expired and permissions
  public tokenValidation() {
    return (1000 * this.user.exp > Date.now())
  }

  // check if user is logged
  public isLogged() {
    return !!this.user.last_name
  }

  // handle logout
  public logout() {
    this.user = { first_name: "guest", last_name: "" }
    this._order.cart = undefined
    localStorage.token = ""
    this._router.navigateByUrl('/lobby/login')
  }

}


