import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OrdersService } from './orders.service';
import { FormControl } from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private _http: HttpClient, public _order: OrdersService) { }

  private product_url = `http://localhost:1000/api/products/`

  public onSearch: boolean = false;

  selected_action = 0
  public can_edit = false
  product = new FormControl("");

  // get all products of certien categories
  public getAllProducts(cat) {
    return this._http.get(this.product_url + "prods/" + cat,
      { headers: { 'token': localStorage.token } }
    )
  }

  // get specific product by the name
  public getProduct(name) {
    return this._http.get(this.product_url + "prod/" + name,
      { headers: { 'token': localStorage.token } }
    )
  }

  // get random product
  public getRandomProduct() {
    return this._http.get(this.product_url + "rand_prod",
      { headers: { 'token': localStorage.token } })
  }

  // get all categories of the shop
  public getAllCategories() {
    return this._http.get(this.product_url + "cat",
      { headers: { 'token': localStorage.token } }
    )
  }

  // save image in static fo;der at server
  public img(img) {
    return this._http.post("http://localhost:1000/single", img)
  }


}
