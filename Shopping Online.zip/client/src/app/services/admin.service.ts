import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ProductsService } from './products.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(public _prod: ProductsService, private _http: HttpClient) { }

  private server_url = 'http://localhost:1000/api/'
  public newOne: boolean

  // get all products of the store
  public getAllProducts() {
    return this._http.get(this.server_url + "products/all_products",
      { headers: { 'token': localStorage.token } }
    )
  }

  // adding order and mark the cart as completed
  public addOrder(body) {
    return this._http.post(this.server_url + "orders/submit_order", body,
      {
        headers: {
          'token': localStorage.token,
          'Content-Type': 'application/json'
        }
      }
    )
  }

  // adding new product
  public addNewProduct(product) {
    return this._http.post(this.server_url + "products/add_prod", product,
      {
        headers: {
          'token': localStorage.token,
          'Content-Type': 'application/json'
        }
      }
    )
  }

  // updating product
  public editProduct(product) {
    return this._http.put(this.server_url + "products/update", product,
      {
        headers: {
          'token': localStorage.token,
          'Content-Type': 'application/json'
        }
      }
    )
  }
}
