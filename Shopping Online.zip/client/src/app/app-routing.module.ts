import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CartComponent } from './components/cart/cart.component';
import { HallComponent } from './components/hall/hall.component';
import { LobbyComponent } from './components/lobby/lobby.component'
import { LoginComponent } from './components/login/login.component';
import { ManageComponent } from './components/manage/manage.component';
import { OrderComponent } from './components/order/order.component';
import { RegStep1Component } from './components/reg-step1/reg-step1.component';
import { RegStep2Component } from './components/reg-step2/reg-step2.component';
import { AuthGuard } from './guards/auth.guard';
import { PermissionGuard } from './guards/permission.guard';
import { SemiRegGuard } from './guards/semi-reg.guard';


const routes: Routes = [
  { path: "", pathMatch: "full", redirectTo: "lobby" },
  {
    path: "lobby", component: LobbyComponent, children: [
      { path: "", pathMatch: "full", redirectTo: "login" },
      { path: "reg1", component: RegStep1Component },
      { path: "reg2", component: RegStep2Component, canActivate: [SemiRegGuard] },
      { path: "login", component: LoginComponent },
    ]
  },
  {
    path: "hall", component: HallComponent, canActivate: [AuthGuard],
    children: [
      { path: "", pathMatch: "full", redirectTo: "cart" },
      {
        path: "cart", component: CartComponent,
        canActivate: [PermissionGuard],
        data: {
          expectedRole: 'user'
        }
      },
      {
        path: "manage", component: ManageComponent,
        canActivate: [PermissionGuard],
        data: {
          expectedRole: 'admin'
        }
      },
      { path: "**", redirectTo: "cart" }
    ]
  },
  {
    path: "order",
    component: OrderComponent,
    canActivate: [AuthGuard, PermissionGuard],
    data: {
      expectedRole: 'user'
    }
  },
  { path: "**", redirectTo: "lobby" },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
