import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UsersService } from '../services/users.service'

@Injectable({
  providedIn: 'root'
})

export class SemiRegGuard implements CanActivate {

  constructor(private _user: UsersService, private _router: Router) { }

  // checking if user fill all the 4 field in the starting register page
  canActivate(): boolean {
    if (Object.keys(this._user.reg1).length == 5) return true
    this._router.navigateByUrl('/lobby/reg1')
    return false
  }
}




