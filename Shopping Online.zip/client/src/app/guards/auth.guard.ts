import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UsersService } from '../services/users.service'

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private _user: UsersService, private _router: Router) { }

  canActivate(): boolean {
    if (this._user.isLogged() && this._user.tokenValidation()) return true
    this._router.navigateByUrl('/lobby')
    return false
  }
}
