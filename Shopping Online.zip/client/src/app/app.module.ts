import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { AboutComponent } from './components/about/about.component';
import { NotificationComponent } from './components/notification/notification.component';
import { HeadComponent } from './components/head/head.component';
import { LobbyComponent } from './components/lobby/lobby.component';
import { ShopComponent } from './components/shop/shop.component';
import { HallComponent } from './components/hall/hall.component';
import { RegStep2Component } from './components/reg-step2/reg-step2.component';
import { RegStep1Component } from './components/reg-step1/reg-step1.component';
import { ManageComponent } from './components/manage/manage.component';
import { CartComponent } from './components/cart/cart.component';
import { ProductComponent } from './components/product/product.component';
import { QuantityComponent } from './components/quantity/quantity.component';
import { OrderComponent } from './components/order/order.component';
import { ShipingComponent } from './components/shiping/shiping.component';
import { EditComponent } from './components/edit/edit.component';
import { AddComponent } from './components/add/add.component';


import { MatTabsModule } from '@angular/material/tabs';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AboutComponent,
    NotificationComponent,
    HeadComponent,
    LobbyComponent,
    ShopComponent,
    HallComponent,
    RegStep2Component,
    RegStep1Component,
    CartComponent,
    ManageComponent,
    ProductComponent,
    QuantityComponent,
    OrderComponent,
    ShipingComponent,
    EditComponent,
    AddComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
    MatTabsModule,
    MatCardModule,
    MatDialogModule,
    MatFormFieldModule,
    MatSidenavModule,
    MatIconModule,
    MatInputModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatSelectModule,
  ],
  providers: [ShopComponent, EditComponent, ManageComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
